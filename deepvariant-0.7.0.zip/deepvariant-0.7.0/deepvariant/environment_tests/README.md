This is for lightweight (smoke) tests that we generally want to run
before anything else.
