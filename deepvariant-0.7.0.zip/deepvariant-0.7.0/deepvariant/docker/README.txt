This is DeepVariant, a suite of programs that uses a deep neural network to call
genetic variants.

The DeepVariant binaries are available in the /opt/deepvariant/bin directory.
Please see
https://github.com/google/deepvariant/blob/master/docs/deepvariant-docker.md for
instructions on how to use the image.

This is not an official Google product.
